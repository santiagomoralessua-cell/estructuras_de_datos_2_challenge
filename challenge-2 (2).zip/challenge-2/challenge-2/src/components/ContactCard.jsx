import React from 'react'

function ContactCard({ contact, onDelete }) {
  // Get initials from name
  const initials = contact.name
    .split(' ')
    .map((word) => word[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  return (
    <div className="contact-card">
      <div className="avatar">{initials}</div>
      <div className="contact-info">
        <p className="contact-name">{contact.name}</p>
        <p className="contact-phone">{contact.phone}</p>
      </div>
      <button
        className="btn-delete"
        onClick={() => onDelete(contact.id)}
        title="Delete contact"
      >
        ✕
      </button>
    </div>
  )
}

export default ContactCard
