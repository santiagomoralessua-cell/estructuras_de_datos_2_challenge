import React, { useState } from 'react'

function ContactForm({ onAdd }) {
  const [name, setName]   = useState('')
  const [phone, setPhone] = useState('')
  const [error, setError] = useState('')

  const handleAdd = () => {
    if (!name.trim() || !phone.trim()) {
      setError('Please fill in both name and phone.')
      return
    }

    onAdd({
      id: Date.now(),
      name: name.trim(),
      phone: phone.trim(),
    })

    setName('')
    setPhone('')
    setError('')
  }

  return (
    <div className="form-card">
      <p className="form-title">Add Contact</p>
      <div className="form-row">
        <input
          className="input"
          placeholder="Full name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
        />
        <input
          className="input"
          placeholder="Phone number"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
        />
        <button className="btn-add" onClick={handleAdd}>
          + Add
        </button>
      </div>
      {error && <p className="error">{error}</p>}
    </div>
  )
}

export default ContactForm
