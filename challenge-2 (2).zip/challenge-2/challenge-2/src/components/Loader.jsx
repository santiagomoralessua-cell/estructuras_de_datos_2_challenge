import React from 'react'

function Loader() {
  return (
    <div className="loader-wrap">
      <div className="loader-ring" />
      <p className="loader-text">Loading contacts...</p>
    </div>
  )
}

export default Loader
