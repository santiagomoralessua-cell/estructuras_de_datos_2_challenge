import React from 'react'
import ContactCard from './ContactCard'

function ContactList({ contacts, onDelete }) {
  if (contacts.length === 0) {
    return (
      <div className="empty">
        <div className="empty-icon">📭</div>
        <p>No contacts yet. Add one above!</p>
      </div>
    )
  }

  return (
    <div className="contact-list">
      {contacts.map((contact) => (
        <ContactCard
          key={contact.id}
          contact={contact}
          onDelete={onDelete}
        />
      ))}
    </div>
  )
}

export default ContactList
