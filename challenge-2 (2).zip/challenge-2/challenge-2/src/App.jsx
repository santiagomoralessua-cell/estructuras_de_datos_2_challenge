import React, { useState, useEffect } from 'react'
import './styles/App.css'
import Loader from './components/Loader'
import ContactForm from './components/ContactForm'
import ContactList from './components/ContactList'

// Initial data simulating a database load
const INITIAL_CONTACTS = [
  { id: 1, name: 'Ana García',       phone: '+57 300 123 4567' },
  { id: 2, name: 'Carlos López',     phone: '+57 311 987 6543' },
  { id: 3, name: 'María Rodríguez',  phone: '+57 320 456 7890' },
  { id: 4, name: 'Juan Martínez',    phone: '+57 315 321 0987' },
]

function App() {
  const [contacts, setContacts] = useState([])
  const [loading, setLoading]   = useState(true)

  // Simulate async data loading on startup
  useEffect(() => {
    setTimeout(() => {
      setContacts(INITIAL_CONTACTS)
      setLoading(false)
    }, 2400)
  }, [])

  // Add a new contact
  const addContact = (newContact) => {
    setContacts((prev) => [newContact, ...prev])
  }

  // Delete contact by id
  const deleteContact = (id) => {
    setContacts((prev) => prev.filter((contact) => contact.id !== id))
  }

  return (
    <>
      {loading && <Loader />}
      <div className="app">
        <div className="header">
          <p className="header-label">Challenge 02</p>
          <h1>My <span>Contacts</span></h1>
          <p className="contact-count">
            {contacts.length} contact{contacts.length !== 1 ? 's' : ''} saved
          </p>
        </div>

        <ContactForm onAdd={addContact} />

        <p className="list-title">All contacts</p>
        <ContactList contacts={contacts} onDelete={deleteContact} />
      </div>
    </>
  )
}

export default App
